---
layout: manifest
permalink: /manifest.json
---